
const db=[{name:'迪西温馨提醒：结合后台和postman观察哦，为你开通put，del，post，get功能'}]
class UserCtl {
    find(ctx) {
        console.log('/是调用db静态数据')
        ctx.body = db
    }

    findById(ctx) {
        if(ctx.params.id*1>=db.length){
            ctx.throw(412,'先决条件失败：id大于数组长度了')
        }
        console.log('get获取特定用户')
        ctx.body = db[ctx.params.id * 1]

    }

    create(ctx) {
        console.log('新建一只天线小宝功能,get:/得到数据')
        db.push(ctx.request.body)
        ctx.body = ctx.request.body
    }

    update(ctx) {
        console.log('put修改特定用户')
        db[ctx.params.id * 1] = ctx.request.body;
        ctx.body = ctx.request.body
    }

    delete(ctx) {
        console.log('拒接宝宝')
        db.splice(ctx.params.id * 1, 1)
        ctx.body = 204
    }
}
module.exports=new UserCtl()