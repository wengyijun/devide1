const Koa=require('koa');
const KoaBody=require('koa-body');
const koaStatic=require('koa-static')
const error=require('koa-json-error')
const parameter=require('koa-parameter')
const mongoose=require('mongoose')
const app=new Koa()
const path=require('path')
const routing=require('./routes')
const {connectionStr}=require('./config')
mongoose.connect(connectionStr,()=>console.log('数据库连接'))
mongoose.connection.on('error',console.error)
app.use(async(ctx,next)=>{
    try{
        await next()

    }catch(err){
        ctx.status=err.status||err.statusCode
        ctx.body={
            message:err.message
        }
    }
})
app.use(koaStatic(path.join(__dirname, 'public')));
app.use(error({
    postFormat:(e,{stack,...rest})=>process.env.NODE_ENV==='production'?rest:{stack,...rest}
}))
app.use( KoaBody({
    multipart:true,
    formidable:{
        uploadDir:path.join(__dirname,'/public/uploads'),
        keepExtensions:true,
    },
}))
app.use(parameter(app))
routing(app)

app.listen(3000,()=>console.log('程序启动在3000端口'));
