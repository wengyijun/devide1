
class HomeCtl{
    index(ctx){

        ctx.set('Allow','GET,POST,del,put')
        console.log('admins列表')
        ctx.body=[
            {name:'迪西'},
            {name:'拉拉'},
            {name:'小波'},
            {name:'丁丁'},
        ]
    }
}
module.exports=new HomeCtl();