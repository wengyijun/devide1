
class HomeCtl{
    index(ctx){

        ctx.set('Allow','GET,POST,del,put')
        console.log('admins列表')
        ctx.body=[
            {name:'迪西'},
            {name:'拉拉'},
            {name:'小波'},
            {name:'丁丁'},
        ]
    }
    upload(ctx){
        const file=ctx.request.files.file
        ctx.body={path:file.path}
    }
}
module.exports=new HomeCtl();