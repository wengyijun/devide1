module.exports={
    secret:'zhihu-jwt-secret',
    connectionStr:'mongodb+srv://hello:hello@cluster0-3z0bl.mongodb.net/test?retryWrites=true&w=majority'
}