const User=require('../models/users')
class UserCtl {
    async find(ctx) {
        ctx.body=await User.find()
    }

    async findById(ctx){
        const user=await User.findByid(ctx.params.id)
        if(!user){
            ctx.throw(404,'用户不存在')
        }
        ctx.body=user

    }

    async create(ctx) {
        ctx.verifyParams({
            name:{type:'string',require:true},
        })
        const user=await new User(ctx.request.body).save()
        ctx.body=user
    }

    update(ctx) {
        if(ctx.params.id*1>=db.length){
            ctx.throw(412,'先决条件失败：id大于数组长度了')
        }
        ctx.verifyParams({
            name:{type:'string',required:true},
            age:{type:'number',required:false}
        })
        console.log('put修改特定用户')
        db[ctx.params.id * 1] = ctx.request.body;
        ctx.body = ctx.request.body
    }

    delete(ctx) {
        if(ctx.params.id*1>=db.length){
            ctx.throw(412,'先决条件失败：id大于数组长度了')
        }
        console.log('拒接宝宝')
        db.splice(ctx.params.id * 1, 1)
        ctx.body = 204
    }
}
module.exports=new UserCtl()